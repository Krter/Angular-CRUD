import { Injectable} from '@angular/core';
import {Recipe} from './recipe.model';
import {Ingredient} from '../shared/ingredient.model';
import {ShoppingListService } from '../shopping-list/shopping-list.service';
@Injectable()
export class RecipeService{
    //recipeSelected = new EventEmitter<Recipe>();
    constructor(private slService: ShoppingListService){}
    private  recipes: Recipe[]=[
        new Recipe('A Test Recipe','This is simply a test',
         "http://www.seriouseats.com/recipes/assets_c/2017/03/Stir_Fried_Lo_Mein_20170315_3-edit-thumb-1500xauto-436988.jpg",
         [
             new Ingredient('Meat',1),
             new Ingredient('French Fries',20)
         ])
         ,
         new Recipe('A Another Recipe','This is another test',
         "http://www.seriouseats.com/recipes/assets_c/2017/03/Stir_Fried_Lo_Mein_20170315_3-edit-thumb-1500xauto-436988.jpg",
         [   new Ingredient('Fruits',1),
             new Ingredient('Veggies',20)
         ])
     ];

  getRecipes(){
      return this.recipes.slice();
  }

  getRecipe(index: number){
      return this.recipes[index];
  }

  addIngredientsToShoppingList(ingredients: Ingredient[]){
      this.slService.addMultipleIngredients(ingredients);
  }
}